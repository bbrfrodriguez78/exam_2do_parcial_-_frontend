#!/bin/bash
waitress-serve --port=$PORT app:app